/** Automatically generated file. DO NOT MODIFY */
package com.speedata.pasm;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}